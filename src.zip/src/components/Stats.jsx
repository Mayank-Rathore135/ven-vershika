import React from "react";
import { Leaf, Users, Trophy, TreePine } from "lucide-react";

const Stats = () => {
  const stats = [
    {
      icon: TreePine,
      number: "500+",
      label: "Gardens Designed",
    },
    {
      icon: Users,
      number: "1200+",
      label: "Happy Clients",
    },
    {
      icon: Trophy,
      number: "15+",
      label: "Years Experience",
    },
    {
      icon: Leaf,
      number: "98%",
      label: "Client Satisfaction",
    },
  ];

  return (
    <section className="relative overflow-hidden bg-[#12351c] px-5 py-20 md:px-10 lg:px-20">
      <div className="absolute -left-20 top-0 h-72 w-72 rounded-full bg-green-400/20 blur-3xl"></div>
      <div className="absolute -right-20 bottom-0 h-72 w-72 rounded-full bg-lime-400/20 blur-3xl"></div>

      <div className="relative mx-auto grid max-w-7xl gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((item, index) => {
          const Icon = item.icon;

          return (
            <div
              key={index}
              className="group rounded-[28px] border border-white/10 bg-white/10 p-8 text-center backdrop-blur-xl transition-all duration-500 hover:-translate-y-3 hover:bg-white/15"
            >
              <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-white text-green-700 shadow-lg transition-all duration-500 group-hover:rotate-6 group-hover:scale-110">
                <Icon size={30} />
              </div>

              <h3 className="text-4xl font-black text-white md:text-5xl">
                {item.number}
              </h3>

              <p className="mt-3 text-sm font-semibold uppercase tracking-[1.5px] text-green-100">
                {item.label}
              </p>
            </div>
          );
        })}
      </div>
    </section>
  );
};

export default Stats;