function Contact() {
  return (
    <section id="contact" className="bg-white px-5 py-24">
      <div className="mx-auto grid max-w-7xl gap-14 lg:grid-cols-2">
        <div>
          <span className="text-sm font-black uppercase tracking-[0.2em] text-green-700">
            Contact
          </span>

          <h2 className="mt-3 text-4xl font-black text-green-950 md:text-5xl">
            Let’s create your dream garden.
          </h2>

          <div className="mt-8 space-y-3 text-lg font-semibold text-gray-700">
            <p>📞 +91 98765 43210</p>
            <p>✉️ hello@greenaura.com</p>
            <p>📍 Delhi NCR, India</p>
          </div>
        </div>

        <form className="space-y-5 rounded-[2rem] bg-[#eef7ed] p-8">
          <input
            type="text"
            placeholder="Your Name"
            className="w-full rounded-2xl border border-green-100 bg-white px-5 py-4 outline-none focus:border-green-600"
          />

          <input
            type="email"
            placeholder="Your Email"
            className="w-full rounded-2xl border border-green-100 bg-white px-5 py-4 outline-none focus:border-green-600"
          />

          <input
            type="text"
            placeholder="Project Type"
            className="w-full rounded-2xl border border-green-100 bg-white px-5 py-4 outline-none focus:border-green-600"
          />

          <textarea
            placeholder="Tell us about your project"
            rows="5"
            className="w-full resize-none rounded-2xl border border-green-100 bg-white px-5 py-4 outline-none focus:border-green-600"
          ></textarea>

          <button
            type="button"
            className="w-full rounded-2xl bg-green-800 py-4 font-black text-white transition hover:bg-green-700"
          >
            Send Message
          </button>
        </form>
      </div>
    </section>
  );
}

export default Contact;