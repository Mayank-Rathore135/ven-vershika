import React from "react";
import { ArrowRight, PhoneCall } from "lucide-react";

const CTA = () => {
  return (
    <section className="bg-white px-5 py-24 md:px-10 lg:px-20">
      <div className="relative mx-auto max-w-7xl overflow-hidden rounded-[40px] bg-[#12351c] px-6 py-16 text-center shadow-[0_30px_100px_rgba(18,53,28,0.28)] md:px-12 lg:px-20">
        <div className="absolute -left-24 top-0 h-80 w-80 rounded-full bg-green-400/25 blur-3xl"></div>
        <div className="absolute -right-24 bottom-0 h-80 w-80 rounded-full bg-lime-400/25 blur-3xl"></div>

        <div className="relative z-10 mx-auto max-w-3xl">
          <span className="inline-flex rounded-full border border-white/20 bg-white/10 px-5 py-2 text-sm font-bold uppercase tracking-[2px] text-lime-300 backdrop-blur">
            Start Your Green Project
          </span>

          <h2 className="mt-6 text-3xl font-black leading-tight text-white md:text-5xl">
            Ready to Transform Your Outdoor Space?
          </h2>

          <p className="mt-5 text-base leading-relaxed text-green-100 md:text-lg">
            Let our landscaping experts design a beautiful, fresh, and peaceful
            green space for your home, villa, office, or commercial property.
          </p>

          <div className="mt-9 flex flex-col justify-center gap-4 sm:flex-row">
            <a
              href="#contact"
              className="inline-flex items-center justify-center gap-3 rounded-full bg-white px-8 py-4 text-sm font-black uppercase tracking-[1.5px] text-green-700 transition-all duration-300 hover:bg-lime-400 hover:text-[#12351c]"
            >
              Get Free Consultation
              <ArrowRight size={19} />
            </a>

            <a
              href="tel:+919999999999"
              className="inline-flex items-center justify-center gap-3 rounded-full border border-white/25 bg-white/10 px-8 py-4 text-sm font-black uppercase tracking-[1.5px] text-white backdrop-blur transition-all duration-300 hover:bg-white hover:text-green-700"
            >
              <PhoneCall size={19} />
              Call Now
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTA;