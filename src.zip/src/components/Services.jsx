import { useState } from "react";
import { services } from "../data/siteData";

function Services() {
  const [activeService, setActiveService] = useState(0);
  const selectedService = services[activeService];

  return (
    <section id="services" className="bg-[#eef7ed] px-5 py-20">
      <div className="mx-auto max-w-7xl">
        <div className="mb-10 text-center">
          <span className="text-sm font-black uppercase tracking-[0.25em] text-green-700">
            Landscaping Services
          </span>

          <h2 className="mt-3 text-4xl font-black text-green-950 md:text-5xl">
            Outdoor Spaces Designed With Nature
          </h2>

          <p className="mx-auto mt-4 max-w-3xl text-base leading-relaxed text-gray-600">
            We design and develop premium landscapes with garden layouts,
            decorative waterfalls, stone pathways, outdoor lighting, designer
            pots and complete green space planning for homes, farmhouses and
            commercial properties.
          </p>
        </div>

        <div className="mx-auto mb-7 flex max-w-6xl flex-wrap justify-center gap-3">
          {services.map((service, index) => (
            <button
              key={index}
              onClick={() => setActiveService(index)}
              className={`rounded-full px-5 py-2.5 text-sm font-black transition ${
                activeService === index
                  ? "bg-green-800 text-white shadow-lg"
                  : "bg-white text-green-900 shadow-sm hover:bg-green-100"
              }`}
            >
              {service.icon} {service.title}
            </button>
          ))}
        </div>

        <div className="mx-auto max-w-6xl rounded-[2rem] bg-white p-4 shadow-2xl">
          <div className="grid min-h-[470px] overflow-hidden rounded-[1.6rem] border border-green-100 md:grid-cols-2">
            <div className="flex h-full flex-col justify-center p-6 md:p-9">
              <span className="w-fit rounded-full bg-green-100 px-4 py-2 text-xs font-black uppercase tracking-[0.15em] text-green-800">
                Professional Landscape Detail
              </span>

              <h3 className="mt-5 text-3xl font-black leading-tight text-green-950 md:text-4xl">
                {selectedService.title}
              </h3>

              <p className="mt-4 text-base leading-7 text-gray-600">
                {selectedService.desc}
              </p>

              <div className="mt-6">
                <h4 className="text-lg font-black text-green-950">
                  What We Include
                </h4>

                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  {selectedService.features.map((feature, index) => (
                    <div
                      key={index}
                      className="rounded-xl bg-[#eef7ed] px-4 py-3 text-sm font-bold text-gray-700"
                    >
                      ✓ {feature}
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                <a
                  href="#contact"
                  className="rounded-full bg-green-800 px-6 py-3 text-center font-black text-white transition hover:bg-green-700"
                >
                  Book Consultation
                </a>

                <a
                  href="#portfolio"
                  className="rounded-full border border-green-800 px-6 py-3 text-center font-black text-green-900 transition hover:bg-green-50"
                >
                  View Landscape Work
                </a>
              </div>
            </div>

            <div className="relative m-5 aspect-square overflow-hidden rounded-[1.5rem]">
              <img
                src={selectedService.image}
                alt={selectedService.title}
                className="h-full w-full object-cover"
              />

              <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent"></div>

              <div className="absolute left-5 top-5 rounded-full bg-white/20 px-4 py-2 text-xs font-black uppercase tracking-[0.15em] text-white backdrop-blur-md">
                {selectedService.icon} Landscape Design
              </div>

              <div className="absolute bottom-0 left-0 p-6 text-white">
                <p className="text-xs font-black uppercase tracking-[0.2em] text-green-300">
                  Selected Service
                </p>

                <h3 className="mt-2 text-3xl font-black leading-tight">
                  {selectedService.title}
                </h3>

                <p className="mt-2 max-w-md text-sm leading-6 text-green-50">
                  {selectedService.short}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Services;