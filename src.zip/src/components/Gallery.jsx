import React from "react";
import { ArrowUpRight } from "lucide-react";

const Gallery = () => {
  const images = [
    {
      title: "Modern Backyard",
      category: "Garden Design",
      image:
        "https://images.unsplash.com/photo-1558904541-efa843a96f01?auto=format&fit=crop&w=900&q=80",
    },
    {
      title: "Luxury Lawn",
      category: "Lawn Care",
      image:
        "https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?auto=format&fit=crop&w=900&q=80",
    },
    {
      title: "Outdoor Seating",
      category: "Patio Design",
      image:
        "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=900&q=80",
    },
    {
      title: "Green Pathway",
      category: "Landscape Build",
      image:
        "https://images.unsplash.com/photo-1598902108854-10e335adac99?auto=format&fit=crop&w=900&q=80",
    },
    {
      title: "Plant Decoration",
      category: "Plant Styling",
      image:
        "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?auto=format&fit=crop&w=900&q=80",
    },
    {
      title: "Villa Garden",
      category: "Premium Garden",
      image:
        "https://images.unsplash.com/photo-1594393404814-4d6b7c9f08e0?auto=format&fit=crop&w=900&q=80",
    },
  ];

  return (
    <section id="gallery" className="bg-white px-5 py-24 md:px-10 lg:px-20">
      <div className="mx-auto max-w-7xl">
        <div className="mb-14 flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
          <div className="max-w-2xl">
            <span className="rounded-full bg-green-50 px-5 py-2 text-sm font-bold uppercase tracking-[2px] text-green-700">
              Our Gallery
            </span>

            <h2 className="mt-6 text-3xl font-black leading-tight text-[#12351c] md:text-5xl">
              Beautiful Outdoor Spaces We Create
            </h2>
          </div>

          <p className="max-w-xl text-base leading-relaxed text-gray-600 md:text-lg">
            Explore our garden designs, lawn transformations, plant styling, and
            outdoor living spaces created with detail and care.
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {images.map((item, index) => (
            <div
              key={index}
              className="group relative h-[320px] overflow-hidden rounded-[30px] shadow-lg"
            >
              <img
                src={item.image}
                alt={item.title}
                className="h-full w-full object-cover transition-all duration-700 group-hover:scale-110"
              />

              <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent"></div>

              <div className="absolute bottom-0 left-0 right-0 p-7 text-white">
                <p className="mb-2 text-sm font-bold uppercase tracking-[2px] text-lime-300">
                  {item.category}
                </p>

                <div className="flex items-center justify-between gap-4">
                  <h3 className="text-2xl font-black">{item.title}</h3>

                  <span className="flex h-11 w-11 items-center justify-center rounded-full bg-white/20 backdrop-blur transition-all duration-300 group-hover:bg-green-600">
                    <ArrowUpRight size={22} />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Gallery;