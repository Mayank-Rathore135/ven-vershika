import React, { useState } from "react";
import { ChevronDown } from "lucide-react";

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState(0);

  const faqs = [
    {
      question: "Do you provide complete garden design services?",
      answer:
        "Yes, we provide complete garden design services including planning, plant selection, lawn setup, pathways, lighting, and outdoor styling.",
    },
    {
      question: "How much does landscaping cost?",
      answer:
        "The cost depends on garden size, design requirements, plants, materials, and maintenance needs. We provide a custom quote after understanding your space.",
    },
    {
      question: "Do you offer regular maintenance?",
      answer:
        "Yes, we provide weekly, monthly, and seasonal maintenance plans to keep your garden healthy, clean, and fresh.",
    },
    {
      question: "How long does a landscaping project take?",
      answer:
        "Small projects can take a few days, while complete garden transformations may take one to three weeks depending on the design and area size.",
    },
    {
      question: "Can you design small balcony or terrace gardens?",
      answer:
        "Yes, we also design balcony gardens, terrace gardens, indoor plant corners, and small outdoor spaces.",
    },
  ];

  return (
    <section id="faq" className="bg-[#f4fbf2] px-5 py-24 md:px-10 lg:px-20">
      <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:items-start">
        <div>
          <span className="rounded-full border border-green-200 bg-white px-5 py-2 text-sm font-bold uppercase tracking-[2px] text-green-700">
            FAQ
          </span>

          <h2 className="mt-6 text-3xl font-black leading-tight text-[#12351c] md:text-5xl">
            Questions People Ask Before Starting
          </h2>

          <p className="mt-5 text-base leading-relaxed text-gray-600 md:text-lg">
            Here are some common questions about our landscaping, garden design,
            and maintenance services.
          </p>

          <a
            href="#contact"
            className="mt-8 inline-flex rounded-full bg-green-700 px-7 py-4 text-sm font-black uppercase tracking-[1.5px] text-white transition-all duration-300 hover:bg-[#12351c]"
          >
            Ask Your Question
          </a>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="overflow-hidden rounded-3xl border border-green-100 bg-white shadow-[0_15px_45px_rgba(22,59,31,0.06)]"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="flex w-full items-center justify-between gap-5 p-6 text-left"
              >
                <span className="text-lg font-black text-[#12351c]">
                  {faq.question}
                </span>

                <ChevronDown
                  className={`shrink-0 text-green-700 transition-all duration-300 ${
                    openIndex === index ? "rotate-180" : ""
                  }`}
                  size={24}
                />
              </button>

              <div
                className={`grid transition-all duration-500 ${
                  openIndex === index
                    ? "grid-rows-[1fr] opacity-100"
                    : "grid-rows-[0fr] opacity-0"
                }`}
              >
                <div className="overflow-hidden">
                  <p className="px-6 pb-6 leading-relaxed text-gray-600">
                    {faq.answer}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;