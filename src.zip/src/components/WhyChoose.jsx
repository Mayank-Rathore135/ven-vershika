import { useState } from "react";
import { whyChooseItems } from "../data/siteData";

function WhyChoose() {
  const [selectedItem, setSelectedItem] = useState(whyChooseItems[0]);

  return (
    <section className="relative overflow-hidden bg-[#eef7ed] px-5 py-20">
      <div className="relative mx-auto max-w-8xl overflow-hidden rounded-[3rem] bg-[#042313] px-6 py-14 text-white shadow-2xl md:px-10 lg:px-12">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(74,222,128,0.22),transparent_35%),radial-gradient(circle_at_bottom_right,rgba(16,185,129,0.18),transparent_35%)]"></div>

        <div className="absolute left-0 top-0 h-full w-full opacity-[0.08]">
          <div className="h-full w-full bg-[linear-gradient(to_right,#ffffff_1px,transparent_1px),linear-gradient(to_bottom,#ffffff_1px,transparent_1px)] bg-[size:70px_70px]"></div>
        </div>

        <div className="absolute -left-28 top-16 h-72 w-72 rounded-full bg-green-400/20 blur-[90px]"></div>
        <div className="absolute -right-28 bottom-12 h-80 w-80 rounded-full bg-emerald-300/20 blur-[100px]"></div>

        <div className="relative">
          <div className="grid items-center gap-14 lg:grid-cols-[1fr_1.1fr]">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full border border-green-300/25 bg-white/10 px-4 py-2 text-xs font-black uppercase tracking-[0.18em] text-green-300 shadow-lg backdrop-blur-md">
                <span className="h-2 w-2 rounded-full bg-green-300 shadow-[0_0_18px_#86efac]"></span>
                Why Choose Us
              </div>

              <h2 className="mt-6 max-w-xl text-4xl font-black leading-[1.05] text-white md:text-5xl">
                We design green spaces that feel premium, peaceful and personal.
              </h2>

              <p className="mt-5 max-w-xl text-base leading-8 text-green-50/75 md:text-lg">
  From terrace gardens to farmhouse landscapes, we create modern,
  low-maintenance outdoor and indoor spaces with smart planning, elegant
  styling and natural beauty. Our work includes garden layout design, lawn
  development, decorative waterfalls, stone pathways, designer pots, outdoor
  lighting, plant selection and complete landscape finishing. Every space is
  planned according to sunlight, area size, property style and your daily use,
  so your garden looks fresh, peaceful, premium and easy to maintain for a long
  time.
</p> 

              <div className="mt-8 flex flex-col gap-4 sm:flex-row">
                <a
                  href="#portfolio"
                  className="group inline-flex items-center justify-center gap-2 rounded-full bg-green-400 px-7 py-4 text-sm font-black text-green-950 shadow-[0_18px_45px_rgba(74,222,128,0.28)] transition duration-300 hover:-translate-y-1 hover:bg-green-300"
                >
                  View Our Work
                  <span className="transition duration-300 group-hover:translate-x-1">
                    →
                  </span>
                </a>

                <a
                  href="#contact"
                  className="inline-flex items-center justify-center rounded-full border border-white/25 bg-white/10 px-7 py-4 text-sm font-black text-white backdrop-blur-md transition duration-300 hover:-translate-y-1 hover:bg-white hover:text-green-950"
                >
                  Get Free Consultation
                </a>
              </div>

              
                
            </div>

            <div className="relative">
              <div className="absolute -left-5 top-8 z-10 hidden rounded-[1.5rem] border border-white/15 bg-white/15 px-5 py-4 shadow-2xl backdrop-blur-xl sm:block">
                <p className="text-xs font-bold uppercase tracking-[0.16em] text-green-200">
                  Selected Feature
                </p>

                <h3 className="mt-1 text-2xl font-black">
                  {selectedItem.title}
                </h3>
              </div>

              <div className="relative overflow-hidden rounded-[2rem] border border-white/15 bg-white/10 p-3 shadow-[0_30px_90px_rgba(0,0,0,0.35)] backdrop-blur-md">
                <img
                  src="https://images.unsplash.com/photo-1558904541-efa843a96f01?auto=format&fit=crop&w=1400&q=80"
                  alt="Premium garden landscape"
                  className="h-[340px] w-full rounded-[1.5rem] object-cover md:h-[450px]"
                />

                <div className="absolute inset-3 rounded-[1.5rem] bg-gradient-to-t from-green-950/95 via-green-950/35 to-transparent"></div>

                <div className="absolute bottom-7 left-7 right-7">
                  <div className="mb-4 grid h-14 w-14 place-items-center rounded-[1.3rem] bg-green-400 text-3xl text-green-950 shadow-xl shadow-black/30">
                    {selectedItem.icon}
                  </div>

                  <p className="text-xs font-black uppercase tracking-[0.2em] text-green-300">
                    Selected Detail
                  </p>

                  <h3 className="mt-2 max-w-md text-3xl font-black leading-tight">
                    {selectedItem.title}
                  </h3>

                  <p className="mt-3 max-w-xl text-sm leading-7 text-green-50/80">
                    {selectedItem.text}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {whyChooseItems.map((item, index) => (
              <button
                type="button"
                key={index}
                onClick={() => setSelectedItem(item)}
                className={`group relative overflow-hidden rounded-[2rem] border p-6 text-left shadow-xl backdrop-blur-md transition duration-500 hover:-translate-y-2 ${
                  selectedItem.title === item.title
                    ? "border-green-300/70 bg-green-400/20"
                    : "border-white/10 bg-white/[0.09] hover:border-green-300/40 hover:bg-white/[0.14]"
                }`}
              >
                <div className="absolute -right-10 -top-10 h-28 w-28 rounded-full bg-green-300/10 blur-2xl transition duration-500 group-hover:bg-green-300/25"></div>

                <div
                  className={`relative mb-5 grid h-14 w-14 place-items-center rounded-[1.4rem] text-3xl shadow-lg shadow-green-950/40 transition duration-500 group-hover:scale-105 ${
                    selectedItem.title === item.title
                      ? "bg-white text-green-950"
                      : "bg-green-400 text-green-950"
                  }`}
                >
                  {item.icon}
                </div>

                <h3 className="relative text-xl font-black text-white">
                  {item.title}
                </h3>

                <p className="relative mt-3 text-sm leading-7 text-green-50/70">
                  {item.text}
                </p>

                <div
                  className={`relative mt-5 h-[2px] rounded-full bg-green-300 transition-all duration-500 ${
                    selectedItem.title === item.title ? "w-24" : "w-12"
                  }`}
                ></div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

export default WhyChoose;