function Footer() {
  return (
    <footer className="bg-green-950 px-5 py-12 text-center text-white">
      <h2 className="text-3xl font-black">🌿 GreenAura</h2>

      <p className="mt-3 text-green-100">
        Premium landscaping portfolio template.
      </p>

      <p className="mt-6 text-sm text-green-100">
        © 2026 GreenAura Landscaping. All rights reserved.
      </p>
    </footer>
  );
}

export default Footer;