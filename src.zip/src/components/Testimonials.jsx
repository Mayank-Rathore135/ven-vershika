import React from "react";
import { Quote, Star } from "lucide-react";

const Testimonials = () => {
  const reviews = [
    {
      name: "Amit Sharma",
      role: "Home Owner",
      text: "The team transformed our backyard into a beautiful green space. Their planning, finishing, and plant selection were excellent.",
    },
    {
      name: "Priya Verma",
      role: "Villa Owner",
      text: "Very professional landscaping service. They understood our idea perfectly and created a premium garden within our budget.",
    },
    {
      name: "Rahul Mehta",
      role: "Commercial Client",
      text: "Our office outdoor area looks completely new now. Clean work, timely delivery, and great maintenance support.",
    },
  ];

  return (
    <section
      id="testimonials"
      className="bg-[#f4fbf2] px-5 py-24 md:px-10 lg:px-20"
    >
      <div className="mx-auto max-w-7xl">
        <div className="mx-auto mb-14 max-w-3xl text-center">
          <span className="rounded-full border border-green-200 bg-white px-5 py-2 text-sm font-bold uppercase tracking-[2px] text-green-700">
            Testimonials
          </span>

          <h2 className="mt-6 text-3xl font-black leading-tight text-[#12351c] md:text-5xl">
            What Our Clients Say About Us
          </h2>

          <p className="mt-5 text-base leading-relaxed text-gray-600 md:text-lg">
            Real feedback from clients who trusted us to design and maintain
            their outdoor spaces.
          </p>
        </div>

        <div className="grid gap-7 md:grid-cols-3">
          {reviews.map((review, index) => (
            <div
              key={index}
              className="group rounded-[30px] border border-green-100 bg-white p-8 shadow-[0_20px_60px_rgba(22,59,31,0.08)] transition-all duration-500 hover:-translate-y-3 hover:shadow-[0_30px_80px_rgba(34,139,34,0.16)]"
            >
              <div className="mb-6 flex items-center justify-between">
                <div className="flex gap-1 text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={18} fill="currentColor" />
                  ))}
                </div>

                <Quote className="text-green-100 transition-all duration-500 group-hover:text-green-600" size={42} />
              </div>

              <p className="mb-8 text-base leading-relaxed text-gray-600">
                “{review.text}”
              </p>

              <div className="flex items-center gap-4">
                <div className="flex h-13 w-13 items-center justify-center rounded-full bg-gradient-to-br from-green-700 to-lime-500 text-lg font-black text-white">
                  {review.name.charAt(0)}
                </div>

                <div>
                  <h3 className="font-black text-[#12351c]">{review.name}</h3>
                  <p className="text-sm font-medium text-gray-500">
                    {review.role}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;