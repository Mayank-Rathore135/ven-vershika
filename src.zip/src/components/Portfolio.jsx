import { useEffect, useRef } from "react";
import { projects } from "../data/siteData";

function Portfolio() {
  const portfolioRef = useRef(null);

  const scrollPortfolio = (direction) => {
    if (portfolioRef.current) {
      portfolioRef.current.scrollBy({
        left: direction === "left" ? -560 : 560,
        behavior: "smooth",
      });
    }
  };

  useEffect(() => {
    const autoScroll = setInterval(() => {
      if (portfolioRef.current) {
        const slider = portfolioRef.current;

        if (slider.scrollLeft + slider.clientWidth >= slider.scrollWidth - 5) {
          slider.scrollTo({
            left: 0,
            behavior: "smooth",
          });
        } else {
          slider.scrollBy({
            left: 560,
            behavior: "smooth",
          });
        }
      }
    }, 2500);

    return () => clearInterval(autoScroll);
  }, []);

  return (
    <section id="portfolio" className="bg-white px-5 py-24">
      <div className="mx-auto max-w-[1450px]">
        <div className="mx-auto mb-14 max-w-2xl text-center">
          <span className="text-sm font-black uppercase tracking-[0.2em] text-green-700">
            Portfolio
          </span>

          <h2 className="mt-3 text-4xl font-black text-green-950 md:text-5xl">
            Our Work
          </h2>

          <p className="mt-4 text-gray-600">
            Explore our projects, showcasing sustainable landscapes that tell a
            story.
          </p>
        </div>

        <div className="relative">
          <button
            onClick={() => scrollPortfolio("left")}
            className="absolute left-2 top-1/2 z-20 -translate-y-1/2 text-6xl font-black leading-none text-white transition duration-300 hover:-translate-x-1 hover:scale-110"
          >
            ‹
          </button>

          <button
            onClick={() => scrollPortfolio("right")}
            className="absolute right-2 top-1/2 z-20 -translate-y-1/2 text-6xl font-black leading-none text-white transition duration-300 hover:translate-x-1 hover:scale-110"
          >
            ›
          </button>

          <div
            ref={portfolioRef}
            className="flex gap-8 overflow-x-auto scroll-smooth px-16 pb-8"
            style={{
              scrollbarWidth: "none",
              msOverflowStyle: "none",
            }}
          >
            {projects.map((project, index) => (
              <div
                key={index}
                className="group relative h-[460px] min-w-[320px] overflow-hidden rounded-[2rem] bg-green-950 shadow-xl transition duration-500 hover:-translate-y-3 hover:shadow-2xl sm:min-w-[430px] lg:min-w-[500px] xl:min-w-[540px]"
              >
                <img
                  src={project.image}
                  alt={project.name}
                  className="h-full w-full object-cover object-center transition duration-700 group-hover:scale-110"
                />

                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent transition duration-500 group-hover:from-green-950/95"></div>

                <div className="absolute left-5 top-5 rounded-full bg-white/20 px-4 py-2 text-xs font-black uppercase tracking-[0.15em] text-white backdrop-blur-md transition duration-500 group-hover:bg-green-500">
                  {project.category}
                </div>

                <div className="absolute bottom-0 left-0 p-7 text-white">
                  <p className="mb-2 text-xs font-black uppercase tracking-[0.2em] text-green-300">
                    GreenAura Project
                  </p>

                  <h3 className="text-3xl font-black leading-tight">
                    {project.name}
                  </h3>

                  <p className="mt-3 max-w-sm translate-y-5 text-sm leading-6 text-green-50 opacity-0 transition duration-500 group-hover:translate-y-0 group-hover:opacity-100">
                    A premium landscape project designed with natural elements,
                    clean detailing and modern outdoor styling.
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-10 text-center">
          <p className="text-lg font-semibold text-gray-700">
            Let's create a greener tomorrow, together. Get in touch!
          </p>

          <a
            href="#contact"
            className="mt-6 inline-block rounded-full bg-green-800 px-8 py-4 font-black text-white transition hover:bg-green-700"
          >
            Contact Now
          </a>
        </div>
      </div>
    </section>
  );
}

export default Portfolio;