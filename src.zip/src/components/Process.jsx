import React from "react";
import {
    MessageCircle,
    MapPin,
    PenTool,
    Shovel,
    Leaf,
    ArrowRight,
} from "lucide-react";

const Process = () => {
    const steps = [
        {
            number: "01",
            icon: MessageCircle,
            title: "Free Consultation",
            description:
                "We listen to your ideas, understand your budget, and suggest the right landscaping solution for your outdoor space.",
        },
        {
            number: "02",
            icon: MapPin,
            title: "Site Visit & Analysis",
            description:
                "Our experts inspect soil, sunlight, space layout, drainage, and existing greenery to plan everything correctly.",
        },
        {
            number: "03",
            icon: PenTool,
            title: "Custom Design Plan",
            description:
                "We create a personalized garden concept with lawn, plants, pathways, lighting, seating, and outdoor features.",
        },
        {
            number: "04",
            icon: Shovel,
            title: "Build & Installation",
            description:
                "Our team brings the design to life with quality materials, healthy plants, clean finishing, and skilled execution.",
        },
        {
            number: "05",
            icon: Leaf,
            title: "Care & Maintenance",
            description:
                "We provide regular maintenance support to keep your garden fresh, green, healthy, and beautiful in every season.",
        },
    ];

    return (
        <section
            id="process"
            className="relative overflow-hidden bg-[#f4fbf2] px-5 py-24 md:px-10 lg:px-20"
        >
            <div className="absolute -left-24 top-20 h-72 w-72 rounded-full bg-green-300/30 blur-3xl"></div>
            <div className="absolute -right-24 bottom-10 h-80 w-80 rounded-full bg-lime-300/30 blur-3xl"></div>

            <div className="relative mx-auto max-w-7xl">
                <div className="mx-auto mb-16 max-w-3xl text-center">
                    <span className="inline-flex rounded-full border border-green-200 bg-white/70 px-5 py-2 text-sm font-bold uppercase tracking-[2px] text-green-700 shadow-sm backdrop-blur">
                        Our Working Process
                    </span>

                    <h2 className="mt-6 text-3xl font-black leading-tight text-[#12351c] md:text-5xl">
                        From First Idea to a Beautiful Green Space
                    </h2>

                    <p className="mt-5 text-base leading-relaxed text-gray-600 md:text-lg">
                        We follow a clear and professional process to design, build, and
                        maintain outdoor spaces that look natural, premium, and long-lasting.
                    </p>
                </div>

                <div className="relative">
                    <div className="absolute left-0 right-0 top-20 hidden h-[2px] bg-gradient-to-r from-transparent via-green-300 to-transparent lg:block"></div>

                    <div className="grid gap-7 sm:grid-cols-2 lg:grid-cols-5">
                        {steps.map((step, index) => {
                            const Icon = step.icon;

                            return (
                                <div
                                    key={index}
                                    className="group relative rounded-[28px] border border-white/70 bg-white/80 p-6 shadow-[0_20px_60px_rgba(22,59,31,0.08)] backdrop-blur-xl transition-all duration-500 hover:-translate-y-4 hover:border-green-200 hover:shadow-[0_30px_80px_rgba(34,139,34,0.18)]"
                                >
                                    <div className="absolute inset-x-6 top-0 h-1 rounded-full bg-gradient-to-r from-green-700 via-lime-400 to-green-500"></div>

                                    <div className="relative z-10 mb-6 flex items-center justify-between">
                                        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-green-700 to-lime-500 text-white shadow-lg shadow-green-700/20 transition-all duration-500 group-hover:rotate-6 group-hover:scale-110">
                                            <Icon size={28} strokeWidth={2.4} />
                                        </div>

                                        <span className="text-4xl font-black text-green-100 transition-all duration-500 group-hover:text-green-800 group-hover:scale-110">
                                            {step.number}
                                        </span>
                                    </div>

                                    <h3 className="mb-4 text-xl font-extrabold text-[#12351c]">
                                        {step.title}
                                    </h3>

                                    <p className="text-sm leading-relaxed text-gray-600">
                                        {step.description}
                                    </p>

                                    <div className="mt-7 flex items-center gap-2 text-sm font-bold text-green-700 opacity-0 transition-all duration-500 group-hover:translate-x-1 group-hover:opacity-100">
                                        Learn Step
                                    </div>

                                    <div className="pointer-events-none absolute -bottom-10 -right-10 h-28 w-28 rounded-full bg-green-200/40 blur-2xl transition-all duration-500 group-hover:bg-lime-300/50"></div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Process;