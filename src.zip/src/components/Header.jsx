import { useState } from "react";

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  const navLinks = [
    {
      name: "Home",
      path: "#home",
    },
    {
      name: "About",
      path: "#about",
    },
    {
      name: "Services",
      path: "#services",
    },
    {
      name: "Portfolio",
      path: "#portfolio",
    },
    {
      name: "Contact",
      path: "#contact",
    },
  ];

  return (
    <header className="fixed left-0 top-0 z-50 w-full border-b border-green-100 bg-white/90 backdrop-blur-xl">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4">
        <a href="#home" className="flex items-center gap-3">
          <div className="grid h-12 w-12 place-items-center rounded-2xl bg-green-800 text-2xl text-white shadow-lg">
            🌿
          </div>

          <div>
            <h1 className="text-2xl font-black leading-none text-green-950">
              GreenAura
            </h1>
            <p className="text-xs font-bold text-green-700">
              Landscaping Portfolio
            </p>
          </div>
        </a>

        <div className="hidden items-center gap-8 text-sm font-bold md:flex">
          {navLinks.map((link, index) => (
            <a
              key={index}
              href={link.path}
              className="transition duration-300 hover:text-green-700"
            >
              {link.name}
            </a>
          ))}
        </div>

        <a
          href="#contact"
          className="hidden rounded-full bg-green-800 px-6 py-3 font-bold text-white transition duration-300 hover:bg-green-700 md:inline-block"
        >
          Get Quote
        </a>

        <button
          type="button"
          onClick={() => setMenuOpen(!menuOpen)}
          className="grid h-11 w-11 place-items-center rounded-xl bg-green-100 text-2xl text-green-950 md:hidden"
        >
          {menuOpen ? "✕" : "☰"}
        </button>
      </nav>

      {menuOpen && (
        <div className="space-y-4 border-t border-green-100 bg-white px-5 py-5 font-bold md:hidden">
          {navLinks.map((link, index) => (
            <a
              key={index}
              onClick={() => setMenuOpen(false)}
              href={link.path}
              className="block transition duration-300 hover:text-green-700"
            >
              {link.name}
            </a>
          ))}

          <a
            onClick={() => setMenuOpen(false)}
            href="#contact"
            className="block rounded-full bg-green-800 px-6 py-3 text-center font-bold text-white transition duration-300 hover:bg-green-700"
          >
            Get Quote
          </a>
        </div>
      )}
    </header>
  );
}

export default Header;