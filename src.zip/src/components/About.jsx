import React from "react";
import {
  CheckCircle,
  Leaf,
  Sprout,
  TreePine,
  Flower2,
  ArrowRight,
} from "lucide-react";

function About() {
  const features = [
    "Custom garden and lawn design",
    "Terrace, balcony and outdoor makeover",
    "Premium plants, grass and natural styling",
    "Regular garden care and maintenance",
  ];

  return (
    <section id="about" className="relative overflow-hidden bg-white px-5 py-24 md:px-10 lg:px-20">
      <div className="absolute -left-24 top-20 h-72 w-72 rounded-full bg-green-200/40 blur-3xl"></div>
      <div className="absolute -right-24 bottom-10 h-80 w-80 rounded-full bg-lime-200/50 blur-3xl"></div>

      <div className="relative mx-auto grid max-w-7xl items-center gap-16 lg:grid-cols-[0.95fr_1.05fr]">
        <div className="relative">
          <div className="grid grid-cols-2 gap-5">
            <div className="space-y-5">
              <div className="relative overflow-hidden rounded-[32px] shadow-[0_25px_70px_rgba(18,53,28,0.16)]">
                <img
                  src="https://images.unsplash.com/photo-1416879595882-3373a0480b5b?auto=format&fit=crop&w=800&q=80"
                  alt="Landscape gardening tools and soil"
                  className="h-[340px] w-full object-cover transition-all duration-700 hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-green-950/55 to-transparent"></div>

                <div className="absolute bottom-5 left-5 rounded-2xl bg-white/15 px-4 py-3 text-white backdrop-blur-md">
                  <p className="text-xs font-bold uppercase tracking-[1.5px] text-lime-300">
                    Garden Planning
                  </p>
                  <h3 className="text-lg font-black">Soil to Style</h3>
                </div>
              </div>

              <div className="rounded-[28px] bg-[#12351c] p-6 text-white shadow-[0_25px_70px_rgba(18,53,28,0.22)]">
                <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-lime-400 text-green-950">
                  <Leaf size={28} />
                </div>
                <h3 className="text-4xl font-black">8+</h3>
                <p className="mt-1 text-sm font-medium text-green-100">
                  Years of landscape experience
                </p>
              </div>
            </div>

            <div className="space-y-5 pt-12">
              <div className="relative overflow-hidden rounded-[32px] shadow-[0_25px_70px_rgba(18,53,28,0.16)]">
                <img
                  src="https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?auto=format&fit=crop&w=800&q=80"
                  alt="Fresh plants for landscaping"
                  className="h-[340px] w-full object-cover transition-all duration-700 hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-green-950/50 to-transparent"></div>

                <div className="absolute bottom-5 left-5 rounded-2xl bg-white/15 px-4 py-3 text-white backdrop-blur-md">
                  <p className="text-xs font-bold uppercase tracking-[1.5px] text-lime-300">
                    Plant Styling
                  </p>
                  <h3 className="text-lg font-black">Fresh Green Look</h3>
                </div>
              </div>

              <div className="rounded-[28px] border border-green-100 bg-green-50 p-6 shadow-[0_20px_50px_rgba(18,53,28,0.08)]">
                <div className="flex items-center gap-4">
                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white text-green-700 shadow-md">
                    <TreePine size={28} />
                  </div>
                  <div>
                    <h3 className="text-2xl font-black text-green-950">50+</h3>
                    <p className="text-sm font-semibold text-gray-600">
                      Green spaces designed
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="absolute left-1/2 top-1/2 hidden -translate-x-1/2 -translate-y-1/2 rounded-full border-8 border-white bg-lime-400 p-5 text-green-950 shadow-2xl lg:block">
            <Sprout size={44} />
          </div>
        </div>

        <div>
          <span className="inline-flex items-center gap-2 rounded-full bg-green-50 px-5 py-2 text-sm font-black uppercase tracking-[0.2em] text-green-700">
            <Flower2 size={17} />
            About Landscape Studio
          </span>

          <h2 className="mt-6 text-2xl font-black leading-tight text-green-950 md:text-4xl lg:text-5xl">
            We design landscapes that feel natural, fresh and beautifully planned.
          </h2>
          <p className="mt-6 text-lg leading-relaxed text-gray-600">
            GreenAura is a professional landscaping studio that transforms open outdoor
            spaces into beautiful, functional, and peaceful green environments. We design
            complete landscape layouts for homes, villas, farmhouses, hotels, offices, and
            commercial spaces with proper planning, natural textures, and premium outdoor
            detailing.
          </p>

          <p className="mt-4 text-lg leading-relaxed text-gray-600">
            Our work includes custom garden design, lawn layout, decorative waterfall
            features, stone pathways, outdoor seating areas, landscape lighting, designer
            pots arrangement, boundary decoration, and complete outdoor space makeover.
            From concept planning to final finishing, we create landscapes that look
            natural, elegant, well-balanced, and professionally designed.
          </p>



          <div className="mt-9 flex flex-col gap-4 sm:flex-row">
            <a
              href="#services"
              className="group inline-flex items-center justify-center gap-3 rounded-full bg-green-700 px-8 py-4 font-black text-white shadow-[0_15px_40px_rgba(22,163,74,0.25)] transition-all duration-300 hover:-translate-y-1 hover:bg-green-950"
            >
              Explore Services
              <ArrowRight
                size={19}
                className="transition duration-300 group-hover:translate-x-1"
              />
            </a>

            <a
              href="#portfolio"
              className="inline-flex items-center justify-center rounded-full border border-green-200 bg-green-50 px-8 py-4 font-black text-green-800 transition-all duration-300 hover:-translate-y-1 hover:bg-lime-100"
            >
              View Our Work
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

export default About;