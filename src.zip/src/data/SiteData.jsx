export const services = [
  {
    title: "Terrace & Indoor Gardens",
    short: "Green spaces for modern living",
    desc: "We create green spaces that make every property feel fresh, peaceful and beautifully connected with nature. Our terrace and indoor garden solutions are designed to improve the look, comfort and environment of homes, offices, farmhouses and commercial spaces. From choosing the right plants and designer pots to planning the layout, styling green corners and creating a maintenance-friendly setup, we focus on every detail to deliver a natural, elegant and long-lasting landscape experience.",
    image:
      "https://images.unsplash.com/photo-1598902108854-10e335adac99?auto=format&fit=crop&w=1000&q=80",
    icon: "🌿",
    features: [
      "Terrace garden setup",
      "Indoor plant styling",
      "Air quality improvement",
      "Relaxing green corners",
    ],
  },
  {
    title: "Farmhouse & Garden Landscaping",
    short: "Functional and natural outdoor design",
    desc: "Tailored designs that blend functionality with natural beauty. We create farmhouse and garden landscapes with plant zones, pathways, sitting areas and decorative natural elements.",
    image:
      "https://images.unsplash.com/photo-1558904541-efa843a96f01?auto=format&fit=crop&w=1000&q=80",
    icon: "🌳",
    features: [
      "Farmhouse landscape design",
      "Garden planning",
      "Pathway layout",
      "Outdoor seating areas",
    ],
  },
  {
    title: "Zen Gardens",
    short: "Peaceful and mindful green spaces",
    desc: "Serene escapes that calm the mind and nourish the soul. Zen gardens are designed with simple plants, stones, pathways and natural elements to create a peaceful outdoor atmosphere.",
    image:
      "https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?auto=format&fit=crop&w=1000&q=80",
    icon: "🪨",
    features: [
      "Minimal garden layout",
      "Stone arrangement",
      "Peaceful sitting zone",
      "Natural calm design",
    ],
  },
  {
    title: "Boutique Water Features",
    short: "Custom waterfalls and water corners",
    desc: "Custom waterfalls with real boulder stones, adding tranquility to your space. We design boutique water features that create a luxury focal point in gardens, entrances and courtyards.",
    image:
      "https://images.unsplash.com/photo-1512413316925-fd47914c9c02?auto=format&fit=crop&w=1000&q=80",
    icon: "💧",
    features: [
      "Custom waterfall setup",
      "Real boulder stones",
      "Water flow planning",
      "Luxury garden feature",
    ],
  },
  {
    title: "Fruit Orchards",
    short: "Edible landscapes for fresh produce",
    desc: "Edible landscapes that bring fresh produce and joy to your doorstep. We plan fruit orchards with suitable fruit plants, spacing, soil planning and easy maintenance guidance.",
    image:
      "https://images.unsplash.com/photo-1501004318641-b39e6451bec6?auto=format&fit=crop&w=1000&q=80",
    icon: "🍊",
    features: [
      "Fruit plant selection",
      "Orchard layout planning",
      "Soil and spacing guidance",
      "Easy maintenance setup",
    ],
  },
  {
    title: "Indoor Landscaping",
    short: "Bring the outdoors inside",
    desc: "Bring the outdoors in with custom-designed indoor gardens and green walls. We design indoor plant zones, green walls and decorative plant setups for homes, offices, cafes and showrooms.",
    image:
      "https://images.unsplash.com/photo-1558449028-b53a39d100fc?auto=format&fit=crop&w=1000&q=80",
    icon: "🪴",
    features: [
      "Indoor garden design",
      "Green wall setup",
      "Decorative plant styling",
      "Home and office plants",
    ],
  },
];

export const projects = [
  {
    name: "Modern Backyard Villa",
    category: "Landscape Design",
    image:
      "https://images.unsplash.com/photo-1558904541-efa843a96f01?auto=format&fit=crop&w=1200&q=80",
  },
  {
    name: "Luxury Terrace Garden",
    category: "Terrace Styling",
    image:
      "https://images.unsplash.com/photo-1598902108854-10e335adac99?auto=format&fit=crop&w=1200&q=80",
  },
  {
    name: "Indoor Plant Lounge",
    category: "Interior Green Space",
    image:
      "https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&q=80",
  },
  {
    name: "Zen Garden Corner",
    category: "Peaceful Garden",
    image:
      "https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?auto=format&fit=crop&w=1200&q=80",
  },
  {
    name: "Water Feature Design",
    category: "Luxury Waterfall",
    image:
      "https://images.unsplash.com/photo-1512413316925-fd47914c9c02?auto=format&fit=crop&w=1200&q=80",
  },
  {
    name: "Green Outdoor Sitting",
    category: "Outdoor Decor",
    image:
      "https://images.unsplash.com/photo-1534710961216-75c88202f43e?auto=format&fit=crop&w=1200&q=80",
  },
];

export const whyChooseItems = [
  {
    icon: "🌿",
    title: "Custom Plans",
    text: "Designs made according to space, sunlight, usage and property style.",
  },
  {
    icon: "🪴",
    title: "Premium Plants",
    text: "Suitable indoor and outdoor plants for a clean natural look.",
  },
  {
    icon: "💧",
    title: "Smart Watering",
    text: "Water planning that keeps the garden fresh with less effort.",
  },
  {
    icon: "🪨",
    title: "Natural Styling",
    text: "Stones, pathways, pots and lights for a complete premium finish.",
  },
];